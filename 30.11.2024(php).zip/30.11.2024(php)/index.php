<?php

$host = '192.168.199.13'; 
$user = 'learn'; 
$password = 'learn'; 
$dbname = 'learn_64-shpedt'; 

$conn = new mysqli($host, $user, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$category = isset($_POST['category']) ? $_POST['category'] : '';
$min_price = isset($_POST['min_price']) ? $_POST['min_price'] : '';
$max_price = isset($_POST['max_price']) ? $_POST['max_price'] : '';
$search = isset($_POST['search']) ? $_POST['search'] : '';


$sql = "SELECT * FROM products WHERE 1=1";

if ($category) {
    $sql .= " AND category = '" . $conn->real_escape_string($category) . "'";
}

if ($min_price !== '') {
    $sql .= " AND price >= " . floatval($min_price);
}

if ($max_price !== '') {
    $sql .= " AND price <= " . floatval($max_price);
}

if ($search) {
    $sql .= " AND name LIKE '%" . $conn->real_escape_string($search) . "%'";
}

$result = $conn->query($sql);


$categories = $conn->query("SELECT DISTINCT category FROM products");

?>


<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Фильтрация товаров</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f9f9f9;
        }
        h1, h2 {
            color: #555;
            
        }
        form {
            margin-bottom: 20px;
            padding: 15px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        label {
            display: block;
            margin: 10px 0 5px;
        }
        select, input[type="number"], input[type="text"], input[type="submit"] {
            width: 100%;
            padding: 5px;
            margin-bottom: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
            
        }
        input[type="submit"] {
            background-color: #67d545;
            color: white;
            border: none;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #718856;
        }
        ul {
            list-style-type: none;
            padding: 0;
        }
        li {
            padding: 10px;
            background-color: #fff;
            margin: 5px 0;
            border-radius: 5px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>
<body>

<h1>Фильтрация товаров</h1>
<form method="POST">
    <label for="category">Категория:</label>
    <select name="category" id="category">
        <option value="">Все</option>
        <option value="">Электроника</option>
        <option value="">Одежда</option>
        <option value="">Мебель</option>
        <?php while ($row = $categories->fetch_assoc()): ?>
            <option value="<?= $row['category'] ?>" <?= ($row['category'] == $category) ? 'selected' : '' ?>><?= $row['category'] ?></option>
        <?php endwhile; ?>
    </select><br>

    <label for="min_price">Минимальная цена:</label>
    <input type="number" name="min_price" id="min_price" step="0.01" value="<?= htmlspecialchars($min_price) ?>"><br>

    <label for="max_price">Максимальная цена:</label>
    <input type="number" name="max_price" id="max_price" step="0.01" value="<?= htmlspecialchars($max_price) ?>"><br>

    <label for="search">Поиск по названию:</label>
    <input type="text" name="search" id="search" value="<?= htmlspecialchars($search) ?>"><br>

    <input type="submit" value="Применить фильтры">
</form>

<h2>Товары:</h2>
<ul>
    <?php if ($result->num_rows > 0): ?>
        <?php while($product = $result->fetch_assoc()): ?>
            <li><?=$product['name']?> - <?=$product['category']?> - <?=$product['price']?> руб.</li>
        <?php endwhile; ?>
    <?php else: ?>
        <li>Нет товаров для отображения.</li>
    <?php endif; ?>
</ul>

<?php
$conn->close();
?>
</body>
</html>